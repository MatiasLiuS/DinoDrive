using UnityEngine;

public class VRButtonInteraction : MonoBehaviour
{
    public VRButton button; // Reference to the VRButton script attached to the button object
    public Transform controllerTransform; // Reference to the transform of your VR controller

    void Update()
    {
        // Check for input events (e.g., button press, trigger pull)
        if (Input.GetButtonDown("Fire1")) // Adjust "Fire1" to your input mapping
        {
            // Perform raycasting from the VR controller
            RaycastHit hit;
            if (Physics.Raycast(controllerTransform.position, controllerTransform.forward, out hit))
            {
                // Check if the ray hits the button
                if (hit.collider.gameObject == button.gameObject)
                {
                    // Trigger the button click event
                    button.OnClick();
                }
            }
        }
    }
}
