using UnityEngine;

public class VRButton : MonoBehaviour
{
    public MoveCart moveCartScript; // Reference to the MoveCart script attached to the object you want to trigger

    // Called when the player's ray interacts with the button
    public void OnClick()
    {
        // Check if the moveCartScript reference is assigned
        if (moveCartScript != null)
        {
            // Start moving the cart along waypoints
            moveCartScript.enabled = true;
        }
        else
        {
            Debug.LogWarning("MoveCart script not assigned.");
        }
    }
}
