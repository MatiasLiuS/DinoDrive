using UnityEngine;

public class ClickableObject : MonoBehaviour
{
    public Canvas canvasToActivate;

    private void Start()
    {
        // Ensure the canvas is initially deactivated
        canvasToActivate.gameObject.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Collider entered trigger zone");
        
        // Check if the collider is the controller
        if (other.CompareTag("XRController"))
        {
            // Activate the canvas
            canvasToActivate.gameObject.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        Debug.Log("Collider exited trigger zone");
        
        // Check if the collider is the controller
        if (other.CompareTag("XRController"))
        {
            // Deactivate the canvas
            canvasToActivate.gameObject.SetActive(false);
        }
    }
}
