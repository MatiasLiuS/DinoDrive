using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeInvis : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        // Make the object invisible when the script starts
        gameObject.SetActive(false);
    }
}
