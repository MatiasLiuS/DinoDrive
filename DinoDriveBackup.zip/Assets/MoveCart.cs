using UnityEngine;

public class MoveCart : MonoBehaviour
{
    public GameObject[] WayPoints;

    private int index = 0;
    private float speed = 3f;
    private float rotationSpeed = 2f; //Adjust as needed for smoother turns

    void Update()
    {
        if (index < WayPoints.Length)
        {
            Vector3 targetPosition = WayPoints[index].transform.position;
            float distance = Vector3.Distance(transform.position, targetPosition);

            if (distance < 0.5f)
            {
                index++;
            }

            if (index < WayPoints.Length)
            {
                RotateTowards(targetPosition);
                MoveTowards(targetPosition);
            }
        }
    }


    void RotateTowards(Vector3 targetPosition)
    {
        Quaternion targetRotation = Quaternion.LookRotation(targetPosition - transform.position);
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
    }

    void MoveTowards(Vector3 targetPosition)
    {
        float step = speed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, step);
    }
}
