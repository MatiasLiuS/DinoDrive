﻿using UnityEngine;

public class Notes : MonoBehaviour
{
    [TextArea(20, 1000)]
    public string notes = "- Add notes here";

}
