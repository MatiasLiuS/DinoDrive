using UnityEngine;
using UnityEngine.UI;

public class ButtonController : MonoBehaviour
{
    public MoveCart moveCartScript;

    private Button button;

    void Start()
    {
        button = GetComponent<Button>(); // Get the Button component attached to this GameObject
        button.onClick.AddListener(OnButtonClick); // Add a listener to the button's click event
        moveCartScript.enabled = false; // Ensure the MoveCart script is initially disabled
    }

    void OnButtonClick()
    {
        moveCartScript.enabled = true; // Activate the MoveCart script when the button is clicked
        button.interactable = false; // Disable the button after it's clicked to prevent multiple clicks
    }
}
